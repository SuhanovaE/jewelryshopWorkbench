-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: jewelryshop
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `idclients` int NOT NULL AUTO_INCREMENT,
  `lastname` varchar(45) DEFAULT NULL,
  `firstname` varchar(45) DEFAULT NULL,
  `patronymic` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idclients`),
  UNIQUE KEY `telephone` (`phone`),
  KEY `familia` (`lastname`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'Нефедова','Елена','Дмитриевна','89478456345'),(2,'Никитин','Фёдор','Тимофеевич','89003567876'),(3,'Борисов','Кирилл','Ильич','89234765898'),(4,'Данилова','София','Кирилловна','89278569834'),(5,'Федотова','Амина','Леонидовна','89265873999'),(6,'Журавлёва','Алиса','Олеговна','89478447860'),(7,'Сергеева','Светлана','Богдановна','89308793758'),(8,'Лапина','Мария','Михаловна','89479874623'),(9,'Боброва','Виктория','Михайловна','89375878934'),(10,'Золотова','Александра','Матвеевна','89278573499'),(11,'Николаев','Кирилл','Александрович','89387848926'),(12,'Антонова','София','Дмитриевна','89337863068'),(13,'Борисова','Виктория','Матвеевна','89337865768'),(14,'Мальцева','Екатерина','Семёновна','89378876567'),(15,'Кузнецов','Михаил','Андреевич','89378564588'),(16,'Руднев','Глеб','Давидович','89478763646'),(17,'Баранов','Лев','Артурович','89375654788'),(18,'Федосеева','Дарья','Львовна','89377659898'),(19,'Беляев','Андрей','Семёнович','89376781122'),(20,'Балашов','Артём','Никитич','89378598756'),(21,'Кочетова','Варвара','Ивановна','89479802748'),(22,'Николаев','Андрей','Михайлович','89378889866'),(23,'Королёв','Михаил','Романович','89478654543'),(24,'Шилова','Ксения','Констатиновна','89487233435'),(25,'Петров','Макар','Даниилович','89376598675'),(26,'Александрова','Виктория','Ивановна','89472465476'),(27,'Романов','Иван','Александрович','89472836567'),(28,'Чернова','Ева','Викторовна','89378756544'),(29,'Леонова','Мария','Владиславовна','89467657876'),(30,'Николаева','Анастасия','Георгиевна','89398567234'),(31,'Маркова','Дарья','Матвеевна','89455436452');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `clients_BEFORE_DELETEclient` BEFORE DELETE ON `clients` FOR EACH ROW BEGIN declare k int;
select count(*) into k from clients C join orders O on C.idclients=O.fk_clients where C.idclients = old.idclients;
	if k > 0 then
    signal sqlstate '45000'
    set message_text = 'Нельзя удалить этого клиента';
    end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `delete_client` AFTER DELETE ON `clients` FOR EACH ROW BEGIN
INSERT INTO log Set msg = 'delete', row_id = OLD.idclients, table_name = 'clients';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-15 10:54:24
