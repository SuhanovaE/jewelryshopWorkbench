-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: jewelryshop
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jewellery`
--

DROP TABLE IF EXISTS `jewellery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jewellery` (
  `idjewellery` int NOT NULL AUTO_INCREMENT,
  `weight` float DEFAULT NULL,
  `material` varchar(45) DEFAULT NULL,
  `fk_product_type` int DEFAULT NULL,
  PRIMARY KEY (`idjewellery`),
  KEY `fk_product_type_idx` (`fk_product_type`),
  CONSTRAINT `fk_product_type` FOREIGN KEY (`fk_product_type`) REFERENCES `product_type` (`idproduct_type`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jewellery`
--

LOCK TABLES `jewellery` WRITE;
/*!40000 ALTER TABLE `jewellery` DISABLE KEYS */;
INSERT INTO `jewellery` VALUES (1,8.1,'Золото 750, рубин',1),(2,1.7,'Золото 585',2),(3,6.5,'Серебро 800, турмалин',3),(4,5.2,'Палладий 850',4),(5,7.9,'Серебро 960, изумруд, рубин',5),(6,5.8,'Золото 958, фианит',6),(7,9.6,'Золото 583, изумруд',1),(8,7.2,'Серебро 830, кварц',3),(9,3.4,'Палладий 500',3),(10,2.6,'Серебро 830',2),(11,8.2,'Золото 999, топаз',6),(12,7.7,'Платина 950, рубин',5),(13,8.9,'Палладий 850',4),(14,2.4,'Серебро 960',2),(15,6.6,'Золото 375',4),(16,6.3,'Серебро 925, янтарь',3),(17,9.2,'Палладий 500, топаз, турмалин',5),(18,6.5,'Серебро 800',4),(19,7.8,'Серебро 875, хризолит',1),(20,9.9,'Золото 750, кварц',6),(21,8.5,'Платина 900',3),(22,6.3,'Палладий 500, фианит',4),(23,5.5,'Платина 900, топаз',2),(24,4.2,'Серебро 925',1),(25,6.3,'Серебро 999',5),(26,5.7,'Золото 958, фианит',3),(27,6.8,'Золото 583, янтарь',6),(28,7.3,'Платина 950, рубин',3),(29,4.9,'Палладий 850',4),(31,5.7,'Серебро 830, опал',2);
/*!40000 ALTER TABLE `jewellery` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `jewellery_BEFORE_INSERT` BEFORE INSERT ON `jewellery` FOR EACH ROW BEGIN
IF NEW.weight < 0.1 THEN
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Вес не может быть отрицательным или быть равным 0';
END IF; 

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-15 10:54:24
