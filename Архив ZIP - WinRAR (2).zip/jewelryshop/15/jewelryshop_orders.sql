-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: jewelryshop
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `idorder` int NOT NULL AUTO_INCREMENT,
  `date_of_receipt` date DEFAULT NULL,
  `date_of_issue` date DEFAULT NULL,
  `fk_clients` int DEFAULT NULL,
  `fk_jewellery` int DEFAULT NULL,
  `fk_service` int DEFAULT NULL,
  `price` int DEFAULT NULL,
  `fk_discount` int DEFAULT NULL,
  PRIMARY KEY (`idorder`),
  KEY `fk_clients_idx` (`fk_clients`),
  KEY `fk_jewellery_idx` (`fk_jewellery`),
  KEY `fk_service_idx` (`fk_service`),
  KEY `fk_discount_idx` (`fk_discount`),
  KEY `sizeDiscount` (`fk_discount`),
  KEY `issue_receipt` (`date_of_issue`,`date_of_receipt`),
  CONSTRAINT `fk_clients` FOREIGN KEY (`fk_clients`) REFERENCES `clients` (`idclients`),
  CONSTRAINT `fk_discount` FOREIGN KEY (`fk_discount`) REFERENCES `discount` (`iddiscount`),
  CONSTRAINT `fk_jewellery` FOREIGN KEY (`fk_jewellery`) REFERENCES `jewellery` (`idjewellery`),
  CONSTRAINT `fk_service` FOREIGN KEY (`fk_service`) REFERENCES `service` (`idservice`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'2022-09-10','2022-09-19',1,1,5,2500,2),(2,'2022-09-10','2022-09-15',2,2,6,5000,5),(3,'2022-09-11','2022-09-21',3,3,5,2000,2),(4,'2022-09-13','2022-09-16',4,4,8,500,NULL),(5,'2022-09-13','2022-09-16',5,5,5,2500,2),(6,'2022-09-13','2022-09-16',6,6,6,4500,4),(7,'2022-09-14','2022-09-26',7,7,7,800,NULL),(8,'2022-09-16','2022-09-23',8,8,3,500,NULL),(9,'2022-09-16','2022-09-25',9,9,4,800,NULL),(10,'2022-09-17','2022-09-22',10,10,5,1200,1),(11,'2022-09-17','2022-09-30',11,11,6,3100,3),(12,'2022-09-18','2022-09-29',12,12,2,400,NULL),(13,'2022-09-18','2022-09-25',13,13,3,600,NULL),(14,'2022-09-18','2022-09-30',14,14,6,4600,4),(15,'2022-09-19','2022-10-01',15,15,7,1100,1),(16,'2022-09-19','2022-10-02',16,16,4,2300,2),(17,'2022-09-20','2022-10-01',17,17,3,600,NULL),(18,'2022-09-20','2022-10-01',18,18,2,450,NULL),(19,'2022-09-20','2022-10-02',19,19,4,950,NULL),(20,'2022-09-20','2022-10-03',20,20,5,1700,1),(21,'2022-09-21','2022-09-28',21,21,6,3900,3),(22,'2022-09-25','2022-10-05',22,22,5,1800,2),(23,'2022-09-25','2022-10-03',23,23,1,600,NULL),(24,'2022-09-25','2022-10-06',24,24,8,1050,1),(25,'2022-09-25','2022-10-07',25,25,8,1550,1),(26,'2022-09-25','2022-10-05',26,26,4,300,NULL),(27,'2022-09-26','2022-10-10',27,27,4,800,NULL),(28,'2022-09-26','2022-10-10',28,28,8,1600,1),(29,'2022-09-27','2022-10-12',29,29,6,4150,4),(31,'2022-09-27','2022-10-12',30,31,5,1450,1);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-15 10:54:24
